###############################################################################
# DONE: 1. (2 pts)
#   
#   For this _TODO_, first, copy the line of code from m1 where you created
#   your list and paste it under this _TODO_. We will use this list some more
#   here.
#
#   Now, write a for loop that will loop through each item in the list and
#   print the item.
#
#   When you run your code, you should notice that each item prints on its own
#   line.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################

ingredients = ["sugar", "salt", "flour", "vanilla"]
for x in ingredients:
    print(x)

###############################################################################
# DONE: 2. (3 pt)
#   
#   Let's try using an if statement inside a for loop.
#   
#   For this _TODO_, write a for loop that loops through your list from todo
#   #1. DO NOT copy and paste your list here, just call it using its variable
#   name.
#
#   Inside your loop, include an if statement that checks if "sugar" is in
#   your list of ingredients. If it finds "sugar" in the list, it should print
#   this:
#
#   "I found sugar!"
#
#   Feel free to modify your list to either include sugar or not include sugar
#   to make sure your loop works correctly.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################
for x in ingredients:
    if x in "sugar":
        print(" I found sugar")

###############################################################################
# DONE: 3. (3 pts)
#   
#   For this _TODO_, write a for loop that uses the range() function to print
#   out lines of stars (*) in increasing amounts ending with a line of 5 stars.
#   So it should print the empty string on the first line, then * on the next
#   line, then ** on the next line, and so on. Your final output should look
#   like this:
#
#
#   *
#   **
#   ***
#   ****
#   *****
#
#   NOTE: Remember, lists start with index 0.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################

star = "*"
for x in range(6):
    print("*" * x)